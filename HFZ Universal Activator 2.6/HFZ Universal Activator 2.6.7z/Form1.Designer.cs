﻿namespace HFZ_Universal_Activator_2._6
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.saaPanel1 = new SaaUI.SaaPanel();
            this.saaFormControlBox1 = new SaaUI.SaaFormControlBox();
            this.saaLabel1 = new SaaUI.SaaLabel();
            this.saaLabel2 = new SaaUI.SaaLabel();
            this.saaLabel3 = new SaaUI.SaaLabel();
            this.saaLabel4 = new SaaUI.SaaLabel();
            this.saaLabel5 = new SaaUI.SaaLabel();
            this.saaLabel6 = new SaaUI.SaaLabel();
            this.saaButton1 = new SaaUI.SaaButton();
            this.saaButton2 = new SaaUI.SaaButton();
            this.guna2CheckBox1 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.guna2CheckBox2 = new Guna.UI2.WinForms.Guna2CheckBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.saaLabel7 = new SaaUI.SaaLabel();
            this.saaLabel8 = new SaaUI.SaaLabel();
            this.saaButton3 = new SaaUI.SaaButton();
            this.saaPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.BorderRadius = 15;
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.ResizeForm = false;
            // 
            // saaPanel1
            // 
            this.saaPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.saaPanel1.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(170)))), ((int)(((byte)(255)))));
            this.saaPanel1.BackColorAngle = 90F;
            this.saaPanel1.Border = 0;
            this.saaPanel1.BorderColor = System.Drawing.Color.LightSkyBlue;
            this.saaPanel1.BorderColor2 = System.Drawing.Color.LightSkyBlue;
            this.saaPanel1.BorderColorAngle = 0;
            this.saaPanel1.ColorType = SaaUI.PanelColorType.Default;
            this.saaPanel1.Controls.Add(this.saaButton3);
            this.saaPanel1.Controls.Add(this.saaLabel8);
            this.saaPanel1.Controls.Add(this.saaLabel7);
            this.saaPanel1.Controls.Add(this.guna2CheckBox2);
            this.saaPanel1.Controls.Add(this.guna2CheckBox1);
            this.saaPanel1.Controls.Add(this.saaButton2);
            this.saaPanel1.Controls.Add(this.saaButton1);
            this.saaPanel1.Controls.Add(this.saaLabel6);
            this.saaPanel1.Controls.Add(this.saaLabel5);
            this.saaPanel1.Controls.Add(this.saaLabel4);
            this.saaPanel1.Controls.Add(this.saaLabel3);
            this.saaPanel1.Controls.Add(this.saaLabel2);
            this.saaPanel1.EnableDoubleBuffering = true;
            this.saaPanel1.ForceDrawRegion = true;
            this.saaPanel1.Location = new System.Drawing.Point(-2, 28);
            this.saaPanel1.Name = "saaPanel1";
            this.saaPanel1.Size = new System.Drawing.Size(572, 328);
            this.saaPanel1.TabIndex = 0;
            this.saaPanel1.Transparence = 100;
            // 
            // saaFormControlBox1
            // 
            this.saaFormControlBox1.CloseActive = ((System.Drawing.Image)(resources.GetObject("saaFormControlBox1.CloseActive")));
            this.saaFormControlBox1.CloseInActive = ((System.Drawing.Image)(resources.GetObject("saaFormControlBox1.CloseInActive")));
            this.saaFormControlBox1.CloseTip = "Close";
            this.saaFormControlBox1.DisableClose = false;
            this.saaFormControlBox1.DisableMaximize = false;
            this.saaFormControlBox1.DisableMinimize = false;
            this.saaFormControlBox1.Location = new System.Drawing.Point(-14, 3);
            this.saaFormControlBox1.MaximizeActive = null;
            this.saaFormControlBox1.MaximizeInActive = null;
            this.saaFormControlBox1.MaximizeTip = "Maximize";
            this.saaFormControlBox1.MinimizeActive = ((System.Drawing.Image)(resources.GetObject("saaFormControlBox1.MinimizeActive")));
            this.saaFormControlBox1.MinimizeInActive = ((System.Drawing.Image)(resources.GetObject("saaFormControlBox1.MinimizeInActive")));
            this.saaFormControlBox1.MinimizeTip = "Minimize";
            this.saaFormControlBox1.Name = "saaFormControlBox1";
            this.saaFormControlBox1.ShowClose = true;
            this.saaFormControlBox1.ShowMaximize = true;
            this.saaFormControlBox1.ShowMinimize = true;
            this.saaFormControlBox1.Size = new System.Drawing.Size(64, 21);
            this.saaFormControlBox1.TabIndex = 1;
            // 
            // saaLabel1
            // 
            this.saaLabel1.AutoSize = true;
            this.saaLabel1.BackColor = System.Drawing.Color.Transparent;
            this.saaLabel1.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaLabel1.ForeColor = System.Drawing.Color.White;
            this.saaLabel1.Location = new System.Drawing.Point(157, 6);
            this.saaLabel1.Name = "saaLabel1";
            this.saaLabel1.Size = new System.Drawing.Size(252, 18);
            this.saaLabel1.TabIndex = 2;
            this.saaLabel1.Text = "HFZ Universal Activator 2.6 - GSM & Global";
            // 
            // saaLabel2
            // 
            this.saaLabel2.BackColor = System.Drawing.Color.Transparent;
            this.saaLabel2.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaLabel2.ForeColor = System.Drawing.Color.White;
            this.saaLabel2.Location = new System.Drawing.Point(124, 40);
            this.saaLabel2.Name = "saaLabel2";
            this.saaLabel2.Size = new System.Drawing.Size(327, 18);
            this.saaLabel2.TabIndex = 3;
            this.saaLabel2.Text = "APP_UUID: 74DAB73D-9148-5716-9FBD-6523F673D845";
            // 
            // saaLabel3
            // 
            this.saaLabel3.BackColor = System.Drawing.Color.Transparent;
            this.saaLabel3.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaLabel3.ForeColor = System.Drawing.Color.White;
            this.saaLabel3.Location = new System.Drawing.Point(95, 72);
            this.saaLabel3.Name = "saaLabel3";
            this.saaLabel3.Size = new System.Drawing.Size(385, 18);
            this.saaLabel3.TabIndex = 4;
            this.saaLabel3.Text = "No Device connected";
            this.saaLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // saaLabel4
            // 
            this.saaLabel4.BackColor = System.Drawing.Color.Transparent;
            this.saaLabel4.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaLabel4.ForeColor = System.Drawing.Color.White;
            this.saaLabel4.Location = new System.Drawing.Point(124, 99);
            this.saaLabel4.Name = "saaLabel4";
            this.saaLabel4.Size = new System.Drawing.Size(353, 18);
            this.saaLabel4.TabIndex = 5;
            this.saaLabel4.Text = "UDID:";
            this.saaLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saaLabel4.Visible = false;
            // 
            // saaLabel5
            // 
            this.saaLabel5.BackColor = System.Drawing.Color.Transparent;
            this.saaLabel5.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaLabel5.ForeColor = System.Drawing.Color.White;
            this.saaLabel5.Location = new System.Drawing.Point(148, 132);
            this.saaLabel5.Name = "saaLabel5";
            this.saaLabel5.Size = new System.Drawing.Size(155, 18);
            this.saaLabel5.TabIndex = 6;
            this.saaLabel5.Text = "IMEI:";
            this.saaLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saaLabel5.Visible = false;
            // 
            // saaLabel6
            // 
            this.saaLabel6.BackColor = System.Drawing.Color.Transparent;
            this.saaLabel6.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaLabel6.ForeColor = System.Drawing.Color.White;
            this.saaLabel6.Location = new System.Drawing.Point(310, 132);
            this.saaLabel6.Name = "saaLabel6";
            this.saaLabel6.Size = new System.Drawing.Size(156, 18);
            this.saaLabel6.TabIndex = 7;
            this.saaLabel6.Text = "SN:";
            this.saaLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saaLabel6.Visible = false;
            this.saaLabel6.Click += new System.EventHandler(this.saaLabel6_Click);
            // 
            // saaButton1
            // 
            this.saaButton1.BackColor = System.Drawing.Color.Gray;
            this.saaButton1.BackColor2 = System.Drawing.Color.Gray;
            this.saaButton1.BackColorAngle = 90F;
            this.saaButton1.Border = 1;
            this.saaButton1.BorderColor = System.Drawing.Color.Gray;
            this.saaButton1.BorderColor2 = System.Drawing.Color.DarkGray;
            this.saaButton1.BorderColorAngle = 0;
            this.saaButton1.ClickColor1 = System.Drawing.Color.Silver;
            this.saaButton1.ClickColor2 = System.Drawing.Color.Silver;
            this.saaButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.saaButton1.EnableDoubleBuffering = true;
            this.saaButton1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaButton1.ForeColor = System.Drawing.Color.White;
            this.saaButton1.HoverColor1 = System.Drawing.Color.DimGray;
            this.saaButton1.HoverColor2 = System.Drawing.Color.DimGray;
            this.saaButton1.Icon = ((System.Drawing.Image)(resources.GetObject("saaButton1.Icon")));
            this.saaButton1.IconOffsetX = 5F;
            this.saaButton1.IconOffsetY = 5F;
            this.saaButton1.IconSize = new System.Drawing.Size(20, 20);
            this.saaButton1.Location = new System.Drawing.Point(162, 191);
            this.saaButton1.Name = "saaButton1";
            this.saaButton1.Radius.BottomLeft = 2;
            this.saaButton1.Radius.BottomRight = 2;
            this.saaButton1.Radius.TopLeft = 2;
            this.saaButton1.Radius.TopRight = 2;
            this.saaButton1.Size = new System.Drawing.Size(249, 28);
            this.saaButton1.TabIndex = 8;
            this.saaButton1.TextOffsetX = 0F;
            this.saaButton1.TextOffsetY = 0F;
            this.saaButton1.Value = "Waiting For Device ...";
            this.saaButton1.Click += new System.EventHandler(this.saaButton1_Click_1);
            // 
            // saaButton2
            // 
            this.saaButton2.BackColor = System.Drawing.Color.Gray;
            this.saaButton2.BackColor2 = System.Drawing.Color.Gray;
            this.saaButton2.BackColorAngle = 90F;
            this.saaButton2.Border = 1;
            this.saaButton2.BorderColor = System.Drawing.Color.Gray;
            this.saaButton2.BorderColor2 = System.Drawing.Color.DarkGray;
            this.saaButton2.BorderColorAngle = 0;
            this.saaButton2.ClickColor1 = System.Drawing.Color.Silver;
            this.saaButton2.ClickColor2 = System.Drawing.Color.Silver;
            this.saaButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.saaButton2.EnableDoubleBuffering = true;
            this.saaButton2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaButton2.ForeColor = System.Drawing.Color.White;
            this.saaButton2.HoverColor1 = System.Drawing.Color.DimGray;
            this.saaButton2.HoverColor2 = System.Drawing.Color.DimGray;
            this.saaButton2.Icon = ((System.Drawing.Image)(resources.GetObject("saaButton2.Icon")));
            this.saaButton2.IconOffsetX = 5F;
            this.saaButton2.IconOffsetY = 5F;
            this.saaButton2.IconSize = new System.Drawing.Size(20, 20);
            this.saaButton2.Location = new System.Drawing.Point(199, 230);
            this.saaButton2.Name = "saaButton2";
            this.saaButton2.Radius.BottomLeft = 2;
            this.saaButton2.Radius.BottomRight = 2;
            this.saaButton2.Radius.TopLeft = 2;
            this.saaButton2.Radius.TopRight = 2;
            this.saaButton2.Size = new System.Drawing.Size(175, 28);
            this.saaButton2.TabIndex = 9;
            this.saaButton2.TextOffsetX = 0F;
            this.saaButton2.TextOffsetY = 0F;
            this.saaButton2.Value = "SIM-Lock Check";
            this.saaButton2.Click += new System.EventHandler(this.saaButton2_Click);
            // 
            // guna2CheckBox1
            // 
            this.guna2CheckBox1.AutoSize = true;
            this.guna2CheckBox1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox1.CheckedState.BorderRadius = 0;
            this.guna2CheckBox1.CheckedState.BorderThickness = 0;
            this.guna2CheckBox1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CheckBox1.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2CheckBox1.ForeColor = System.Drawing.Color.White;
            this.guna2CheckBox1.Location = new System.Drawing.Point(279, 294);
            this.guna2CheckBox1.Name = "guna2CheckBox1";
            this.guna2CheckBox1.Size = new System.Drawing.Size(78, 18);
            this.guna2CheckBox1.TabIndex = 10;
            this.guna2CheckBox1.Text = "Skip Setup";
            this.guna2CheckBox1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox1.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox1.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2CheckBox2
            // 
            this.guna2CheckBox2.AutoSize = true;
            this.guna2CheckBox2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox2.CheckedState.BorderRadius = 0;
            this.guna2CheckBox2.CheckedState.BorderThickness = 0;
            this.guna2CheckBox2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CheckBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CheckBox2.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2CheckBox2.ForeColor = System.Drawing.Color.White;
            this.guna2CheckBox2.Location = new System.Drawing.Point(378, 294);
            this.guna2CheckBox2.Name = "guna2CheckBox2";
            this.guna2CheckBox2.Size = new System.Drawing.Size(74, 18);
            this.guna2CheckBox2.TabIndex = 11;
            this.guna2CheckBox2.Text = "Block OTA";
            this.guna2CheckBox2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CheckBox2.UncheckedState.BorderRadius = 0;
            this.guna2CheckBox2.UncheckedState.BorderThickness = 0;
            this.guna2CheckBox2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // backgroundWorker2
            // 
            this.backgroundWorker2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker2_DoWork_1);
            // 
            // saaLabel7
            // 
            this.saaLabel7.BackColor = System.Drawing.Color.Transparent;
            this.saaLabel7.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaLabel7.ForeColor = System.Drawing.Color.White;
            this.saaLabel7.Location = new System.Drawing.Point(165, 263);
            this.saaLabel7.Name = "saaLabel7";
            this.saaLabel7.Size = new System.Drawing.Size(242, 18);
            this.saaLabel7.TabIndex = 12;
            this.saaLabel7.Text = "[SerialNumber is copied to Pasteboard]";
            this.saaLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saaLabel7.Visible = false;
            // 
            // saaLabel8
            // 
            this.saaLabel8.BackColor = System.Drawing.Color.Transparent;
            this.saaLabel8.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaLabel8.ForeColor = System.Drawing.Color.White;
            this.saaLabel8.Location = new System.Drawing.Point(208, 163);
            this.saaLabel8.Name = "saaLabel8";
            this.saaLabel8.Size = new System.Drawing.Size(156, 18);
            this.saaLabel8.TabIndex = 13;
            this.saaLabel8.Text = "STATUS:";
            this.saaLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.saaLabel8.Visible = false;
            // 
            // saaButton3
            // 
            this.saaButton3.BackColor = System.Drawing.Color.Gray;
            this.saaButton3.BackColor2 = System.Drawing.Color.Gray;
            this.saaButton3.BackColorAngle = 90F;
            this.saaButton3.Border = 1;
            this.saaButton3.BorderColor = System.Drawing.Color.Gray;
            this.saaButton3.BorderColor2 = System.Drawing.Color.DarkGray;
            this.saaButton3.BorderColorAngle = 0;
            this.saaButton3.ClickColor1 = System.Drawing.Color.Silver;
            this.saaButton3.ClickColor2 = System.Drawing.Color.Silver;
            this.saaButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.saaButton3.EnableDoubleBuffering = true;
            this.saaButton3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saaButton3.ForeColor = System.Drawing.Color.White;
            this.saaButton3.HoverColor1 = System.Drawing.Color.DimGray;
            this.saaButton3.HoverColor2 = System.Drawing.Color.DimGray;
            this.saaButton3.Icon = ((System.Drawing.Image)(resources.GetObject("saaButton3.Icon")));
            this.saaButton3.IconOffsetX = 5F;
            this.saaButton3.IconOffsetY = 5F;
            this.saaButton3.IconSize = new System.Drawing.Size(20, 20);
            this.saaButton3.Location = new System.Drawing.Point(127, 287);
            this.saaButton3.Name = "saaButton3";
            this.saaButton3.Radius.BottomLeft = 2;
            this.saaButton3.Radius.BottomRight = 2;
            this.saaButton3.Radius.TopLeft = 2;
            this.saaButton3.Radius.TopRight = 2;
            this.saaButton3.Size = new System.Drawing.Size(126, 28);
            this.saaButton3.TabIndex = 14;
            this.saaButton3.TextOffsetX = 0F;
            this.saaButton3.TextOffsetY = 0F;
            this.saaButton3.Value = "HFZRa1n";
            this.saaButton3.Click += new System.EventHandler(this.saaButton3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(571, 357);
            this.Controls.Add(this.saaLabel1);
            this.Controls.Add(this.saaFormControlBox1);
            this.Controls.Add(this.saaPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HFZ Universal Activator 2.6";
            this.saaPanel1.ResumeLayout(false);
            this.saaPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private SaaUI.SaaLabel saaLabel1;
        private SaaUI.SaaFormControlBox saaFormControlBox1;
        private SaaUI.SaaPanel saaPanel1;
        private SaaUI.SaaLabel saaLabel3;
        private SaaUI.SaaLabel saaLabel2;
        private SaaUI.SaaLabel saaLabel6;
        private SaaUI.SaaLabel saaLabel5;
        private SaaUI.SaaLabel saaLabel4;
        private SaaUI.SaaButton saaButton2;
        private SaaUI.SaaButton saaButton1;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox2;
        private Guna.UI2.WinForms.Guna2CheckBox guna2CheckBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private SaaUI.SaaLabel saaLabel7;
        private SaaUI.SaaLabel saaLabel8;
        private SaaUI.SaaButton saaButton3;
    }
}

